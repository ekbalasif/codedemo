
To make a sample BTAS 2018 paper, copy the contents of this directory
somewhere, and type

 latex submission_btas2018_template

or 

 pdflatex submission_btas2018_template

To build your submission, copy submission_btas2018_template.tex to a new file with 
a more appropriate name, e.g. btas2018_my_paper.tex, and proceed. 


